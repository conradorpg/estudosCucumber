# js-cucumber-selenium

[![Build Status](https://travis-ci.org/testcookbook/js-cucumber-selenium.svg?branch=master)](https://travis-ci.org/testcookbook/js-cucumber-selenium)

``` bash
npm install
npm test
```
