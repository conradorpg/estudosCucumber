# HTTParty | Cucumber

Repositório da Postagem do Medium sobre HTTParty
Link postagem: [Automação de Testes com HTTParty e Cucumber](https://medium.com/@rafaelberam/automa%C3%A7%C3%A3o-de-testes-api-com-httparty-e-cucumber-bdd-d955749affa8)

## Bundler
Instale o Bundler:

```ruby
$ gem install bundler
```

## Projeto

>Faça o Clone do projeto
>Execute o comando  para instalar as dependências
```ruby
$ bundle install
```
>Rode o projeto usando o comando

```ruby
$ cucumber
```
