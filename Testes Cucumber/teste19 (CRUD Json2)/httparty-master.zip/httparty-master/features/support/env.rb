require 'httparty'
require 'faker'
require 'rspec'