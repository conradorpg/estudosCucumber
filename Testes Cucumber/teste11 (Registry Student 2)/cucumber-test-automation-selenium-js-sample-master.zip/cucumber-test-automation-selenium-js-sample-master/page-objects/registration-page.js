const registrationPageObjects = {
  studentIdInput: 'enter-student-id',
  registerButton: 'save-btn',
  statusMessageField: 'registration-info',
  loader: 'loader'
};

exports.registrationPageObjects = registrationPageObjects;