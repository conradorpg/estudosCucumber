const notExistingStudentId = '0';

const registeredStudentId = '1';

exports.registeredStudentId = registeredStudentId;
exports.notExistingStudentId = notExistingStudentId;