In order to run the application:

Clone the repo

1)npm install
2)npm start test